'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import axios from '@/lib/axios'
import Card from '@/components/UI/Card'
import Button from '@/components/UI/Button'
import Input from '@/components/UI/Input'
import Modal from '@/components/UI/Modal'
import LoadingState from '@/components/UI/LoadingState'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

// ============ TYPES ============
interface PaperbagPrice {
  id: string
  material_type_id: string
  gsm: string
  sheet_size_id: string
  harga_lembar: string
  updated_at: string | null
  code: string
  panjang_mm: string
  lebar_mm: string
  keterangan: string
  name: string
  material_type: string
  is_premium: string
}

interface MaterialType {
  id: string
  name: string
  material_type: string
  is_premium: string
}

interface SheetSize {
  id: string
  code: string
  panjang_mm: string
  lebar_mm: string
  keterangan: string
}

interface ApiResponse<T = unknown> {
  status: number
  message: string
  data?: T
}

// ============ CONSTANTS ============
const EMPTY_FORM = {
  material_type_id: '',
  gsm: '',
  sheet_size_id: '',
  harga_lembar: '',
}

// ============ MATERIAL STYLE CONFIG ============
// Use static color maps to avoid Tailwind purge issues with dynamic class names
const MATERIAL_STYLES: Record<string, {
  bg: string
  text: string
  border: string
  lightBg: string
  badge: string
  icon: string
  label: string
  hex: string
}> = {
  IV: {
    bg: 'bg-amber-500', text: 'text-amber-700', border: 'border-amber-200',
    lightBg: 'bg-amber-50', badge: 'bg-amber-100 text-amber-700',
    icon: 'mdi:file-document-outline', label: 'Ivory', hex: '#F59E0B'
  },
  AP: {
    bg: 'bg-blue-500', text: 'text-blue-700', border: 'border-blue-200',
    lightBg: 'bg-blue-50', badge: 'bg-blue-100 text-blue-700',
    icon: 'mdi:file-image-outline', label: 'Art Paper', hex: '#3B82F6'
  },
  KP: {
    bg: 'bg-orange-500', text: 'text-orange-700', border: 'border-orange-200',
    lightBg: 'bg-orange-50', badge: 'bg-orange-100 text-orange-700',
    icon: 'mdi:package-variant', label: 'Kraft', hex: '#F97316'
  },
  D: {
    bg: 'bg-purple-500', text: 'text-purple-700', border: 'border-purple-200',
    lightBg: 'bg-purple-50', badge: 'bg-purple-100 text-purple-700',
    icon: 'mdi:layers-triple-outline', label: 'Duplex', hex: '#8B5CF6'
  },
  K: {
    bg: 'bg-yellow-600', text: 'text-yellow-700', border: 'border-yellow-200',
    lightBg: 'bg-yellow-50', badge: 'bg-yellow-100 text-yellow-700',
    icon: 'mdi:package-variant-closed', label: 'Brown Kraft', hex: '#CA8A04'
  },
  W: {
    bg: 'bg-gray-400', text: 'text-gray-600', border: 'border-gray-200',
    lightBg: 'bg-gray-50', badge: 'bg-gray-100 text-gray-600',
    icon: 'mdi:file-outline', label: 'White Kraft', hex: '#9CA3AF'
  },
}

const DEFAULT_STYLE = {
  bg: 'bg-slate-400', text: 'text-slate-600', border: 'border-slate-200',
  lightBg: 'bg-slate-50', badge: 'bg-slate-100 text-slate-600',
  icon: 'mdi:file-outline', label: 'Unknown', hex: '#64748B'
}

const getMStyle = (type: string) => MATERIAL_STYLES[type] || { ...DEFAULT_STYLE, label: type || 'Unknown' }

// ============ UTILS ============
const formatCurrency = (value: string | number) => {
  const num = typeof value === 'string' ? parseFloat(value) : value
  if (isNaN(num)) return 'Rp 0'
  return new Intl.NumberFormat('id-ID', {
    style: 'currency', currency: 'IDR',
    minimumFractionDigits: 0, maximumFractionDigits: 0
  }).format(num)
}

const formatDate = (dateString: string | null): string => {
  if (!dateString) return '-'
  try {
    return new Intl.DateTimeFormat('id-ID', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    }).format(new Date(dateString))
  } catch { return dateString }
}

const formatCm = (mm: string) => {
  const val = parseFloat(mm)
  return isNaN(val) ? mm : `${(val / 10).toFixed(0)} cm`
}

const calcAreaM2 = (panjang: string, lebar: string): number => {
  const p = parseFloat(panjang), l = parseFloat(lebar)
  if (isNaN(p) || isNaN(l)) return 0
  return (p * l) / 1_000_000
}

const formatAreaM2 = (panjang: string, lebar: string): string => {
  const area = calcAreaM2(panjang, lebar)
  return area === 0 ? '—' : `${area.toFixed(4)} m²`
}

const getErrMsg = (err: unknown, fallback: string): string => {
  if (err && typeof err === 'object' && 'response' in err) {
    return (err as { response?: { data?: { message?: string } } }).response?.data?.message || fallback
  }
  return fallback
}

/** Unique key per price row: material_type_id + sheet_size_id + gsm */
const priceKey = (item: PaperbagPrice) =>
  `${item.material_type_id}-${item.sheet_size_id}-${item.gsm}`

// ============ CUSTOM HOOK ============
const usePaperbagPrices = () => {
  const [priceList, setPriceList] = useState<PaperbagPrice[]>([])
  const [materialTypes, setMaterialTypes] = useState<MaterialType[]>([])
  const [sheetSizes, setSheetSizes] = useState<SheetSize[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPrices = useCallback(async () => {
    try {
      setLoading(true); setError(null)
      const { data } = await axios.get<ApiResponse<PaperbagPrice[]>>('/Admin/Paperbag/PaperbagSheetPrices')
      if (data?.status === 200 && Array.isArray(data.data)) {
        setPriceList(data.data)
      } else {
        setPriceList([]); setError('Format response tidak sesuai')
      }
    } catch (err) {
      setError(getErrMsg(err, 'Tidak bisa connect ke server')); setPriceList([])
    } finally { setLoading(false) }
  }, [])

  const fetchMasterData = useCallback(async () => {
    try {
      const [matRes, sizeRes] = await Promise.all([
        axios.get<ApiResponse<MaterialType[]>>('/Admin/Material/MaterialType'),
        axios.get<ApiResponse<SheetSize[]>>('/Admin/Paperbag/PaperbagSheetSizes'),
      ])
      if (matRes.data?.status === 200) setMaterialTypes(matRes.data.data || [])
      if (sizeRes.data?.status === 200) setSheetSizes(sizeRes.data.data || [])
    } catch { /* non-fatal */ }
  }, [])

  useEffect(() => { fetchPrices(); fetchMasterData() }, [fetchPrices, fetchMasterData])

  return { priceList, materialTypes, sheetSizes, loading, error, refetch: fetchPrices }
}

// ============ STATS HOOK ============
const usePriceStats = (priceList: PaperbagPrice[]) =>
  useMemo(() => {
    if (!priceList.length) return { total: 0, minPrice: 0, maxPrice: 0, avgPrice: 0, minGsm: 0, maxGsm: 0, uniqueMat: 0, uniqueSize: 0 }
    const prices = priceList.map(p => parseFloat(p.harga_lembar)).filter(n => !isNaN(n))
    const gsms   = priceList.map(p => parseInt(p.gsm)).filter(g => !isNaN(g))
    return {
      total:      priceList.length,
      minPrice:   Math.min(...prices),
      maxPrice:   Math.max(...prices),
      avgPrice:   prices.reduce((a, b) => a + b, 0) / prices.length,
      minGsm:     Math.min(...gsms),
      maxGsm:     Math.max(...gsms),
      uniqueMat:  new Set(priceList.map(p => p.material_type)).size,
      uniqueSize: new Set(priceList.map(p => p.sheet_size_id)).size,
    }
  }, [priceList])

// ============ SUB-COMPONENTS ============

/** Pill badge with static colors only */
function MatBadge({ type }: { type: string }) {
  const s = getMStyle(type)
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold tracking-wide ${s.badge}`}>
      <Icon icon={s.icon} className="w-3 h-3" />
      {type}
    </span>
  )
}

/** Filter chip button */
function FilterChip({
  active, onClick, icon, label, count
}: { active: boolean; onClick: () => void; icon?: string; label: string; count?: number }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${
        active
          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
          : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-300 hover:text-emerald-700'
      }`}
    >
      {icon && <Icon icon={icon} className="w-3.5 h-3.5" />}
      {label}
      {count !== undefined && (
        <span className={`ml-0.5 text-xs px-1.5 py-0.5 rounded-full font-semibold ${
          active ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-500'
        }`}>{count}</span>
      )}
    </button>
  )
}

/** Stat card */
function StatCard({ icon, label, value, sub, accent }: {
  icon: string; label: string; value: string; sub: string; accent: string
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 flex items-start gap-3 hover:shadow-md transition-shadow">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${accent}`}>
        <Icon icon={icon} className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">{label}</p>
        <p className="text-lg font-bold text-slate-800 mt-0.5 truncate">{value}</p>
        <p className="text-xs text-slate-400 mt-0.5 truncate">{sub}</p>
      </div>
    </div>
  )
}

// ============ MAIN COMPONENT ============
export default function PaperbagSheetPricesPage() {
  const { priceList, materialTypes, sheetSizes, loading, error, refetch } = usePaperbagPrices()
  const stats = usePriceStats(priceList)

  const [isPosting, setIsPosting]   = useState(false)
  const [filterMat, setFilterMat]   = useState<string>('all')
  const [filterSize, setFilterSize] = useState<string>('all')

  const [showViewModal, setShowViewModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showAddModal, setShowAddModal]   = useState(false)
  const [selectedItem, setSelectedItem]   = useState<PaperbagPrice | null>(null)

  const [editForm, setEditForm] = useState(EMPTY_FORM)
  const [addForm, setAddForm]   = useState(EMPTY_FORM)

  // ===== DERIVED DATA =====
  const uniqueMats = useMemo(() => Array.from(new Set(priceList.map(p => p.material_type))).sort(), [priceList])
  const uniqueSizes = useMemo(() =>
    Array.from(new Map(priceList.map(p => [p.sheet_size_id, { id: p.sheet_size_id, code: p.code, keterangan: p.keterangan }])).values())
      .sort((a, b) => a.code.localeCompare(b.code)),
    [priceList]
  )

  const filtered = useMemo(() => priceList.filter(p =>
    (filterMat  === 'all' || p.material_type  === filterMat) &&
    (filterSize === 'all' || p.sheet_size_id  === filterSize)
  ), [priceList, filterMat, filterSize])

  // Group filtered items: key = "material_type|sheet_size_id"
  const grouped = useMemo(() => {
    const map: Record<string, PaperbagPrice[]> = {}
    filtered.forEach(item => {
      const k = `${item.material_type}|${item.sheet_size_id}`
      if (!map[k]) map[k] = []
      map[k].push(item)
    })
    Object.values(map).forEach(arr => arr.sort((a, b) => parseInt(a.gsm) - parseInt(b.gsm)))
    return map
  }, [filtered])

  // Selected size/material for previews
  const selectedAddSize     = useMemo(() => sheetSizes.find(s => s.id === addForm.sheet_size_id),     [sheetSizes, addForm.sheet_size_id])
  const selectedEditSize    = useMemo(() => sheetSizes.find(s => s.id === editForm.sheet_size_id),    [sheetSizes, editForm.sheet_size_id])
  const selectedAddMaterial = useMemo(() => materialTypes.find(m => m.id === addForm.material_type_id),  [materialTypes, addForm.material_type_id])
  const selectedEditMaterial= useMemo(() => materialTypes.find(m => m.id === editForm.material_type_id), [materialTypes, editForm.material_type_id])

  // Reset filters when data changes if filter has no results
  useEffect(() => {
    if (filterMat  !== 'all' && !priceList.some(p => p.material_type === filterMat))  setFilterMat('all')
    if (filterSize !== 'all' && !priceList.some(p => p.sheet_size_id === filterSize)) setFilterSize('all')
  }, [priceList, filterMat, filterSize])

  // ===== HANDLERS =====
  const handleRefresh = useCallback(async () => {
    const r = await Swal.fire({
      icon: 'question', title: 'Refresh Data?', text: 'Data akan dimuat ulang dari server.',
      showCancelButton: true, confirmButtonText: 'Ya, Refresh!', cancelButtonText: 'Batal',
      confirmButtonColor: '#10b981', cancelButtonColor: '#6B7280'
    })
    if (r.isConfirmed) {
      await refetch()
      Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Data berhasil di-refresh!', timer: 1500, showConfirmButton: false })
    }
  }, [refetch])

  const validateForm = (data: typeof EMPTY_FORM): string | null => {
    if (!data.material_type_id) return 'Pilih material terlebih dahulu.'
    if (!data.sheet_size_id)    return 'Pilih ukuran sheet terlebih dahulu.'
    if (isNaN(Number(data.gsm)) || Number(data.gsm) <= 0)                return 'GSM tidak valid.'
    if (isNaN(Number(data.harga_lembar)) || Number(data.harga_lembar) <= 0) return 'Harga lembar tidak valid.'
    return null
  }

  const handleViewClick = (item: PaperbagPrice) => { setSelectedItem(item); setShowViewModal(true) }

  const handleEditClick = (item: PaperbagPrice) => {
    setSelectedItem(item)
    setEditForm({ material_type_id: item.material_type_id, gsm: item.gsm, sheet_size_id: item.sheet_size_id, harga_lembar: item.harga_lembar })
    setShowViewModal(false); setShowEditModal(true)
  }

  const handleUpdate = async () => {
    if (!selectedItem) return
    const err = validateForm(editForm)
    if (err) { Swal.fire({ icon: 'error', title: 'Validasi Error', text: err, confirmButtonColor: '#10b981' }); return }
    try {
      setIsPosting(true)
      const fd = new URLSearchParams()
      fd.append('material_type_id', editForm.material_type_id)
      fd.append('panjang_mm', editForm.gsm) // backend workaround
      fd.append('sheet_size_id', editForm.sheet_size_id)
      fd.append('harga_lembar', editForm.harga_lembar)
      const { data } = await axios.put<ApiResponse>(
        `/Admin/Paperbag/PaperbagSheetPricesEdit/${selectedItem.id}`,
        fd.toString(), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      )
      if (data?.status === 200) {
        await Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Data harga sheet berhasil diperbarui!', timer: 1500, showConfirmButton: false })
        setShowEditModal(false); setSelectedItem(null); await refetch()
      } else Swal.fire({ icon: 'error', title: 'Error!', text: data?.message || 'Gagal menyimpan data' })
    } catch (err) { Swal.fire({ icon: 'error', title: 'Error!', text: getErrMsg(err, 'Gagal menyimpan data') }) }
    finally { setIsPosting(false) }
  }

  const handleAdd = async () => {
    const err = validateForm(addForm)
    if (err) { Swal.fire({ icon: 'error', title: 'Validasi Error', text: err, confirmButtonColor: '#10b981' }); return }
    try {
      setIsPosting(true)
      const fd = new URLSearchParams()
      fd.append('material_type_id', addForm.material_type_id)
      fd.append('panjang_mm', addForm.gsm)
      fd.append('sheet_size_id', addForm.sheet_size_id)
      fd.append('harga_lembar', addForm.harga_lembar)
      const { data } = await axios.post<ApiResponse>(
        '/Admin/Paperbag/PaperbagSheetPricesAdd',
        fd.toString(), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      )
      if (data?.status === 200) {
        await Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Harga sheet baru berhasil ditambahkan!', timer: 1500, showConfirmButton: false })
        setShowAddModal(false); setAddForm(EMPTY_FORM); await refetch()
      } else Swal.fire({ icon: 'error', title: 'Error!', text: data?.message || 'Gagal menambahkan data' })
    } catch (err) { Swal.fire({ icon: 'error', title: 'Error!', text: getErrMsg(err, 'Gagal menambahkan data') }) }
    finally { setIsPosting(false) }
  }

  const handleDelete = async (item: PaperbagPrice) => {
    const r = await Swal.fire({
      icon: 'warning',
      title: 'Hapus Data?',
      html: `
        Yakin ingin menghapus harga berikut?<br/>
        <div style="margin:12px 0;padding:10px 14px;background:#F8FAFC;border-radius:8px;border:1px solid #E2E8F0;text-align:left;font-size:13px;line-height:1.8">
          <b>Material :</b> ${item.name} (${item.material_type})<br/>
          <b>Ukuran &nbsp;&nbsp;:</b> ${item.keterangan} (${item.code})<br/>
          <b>GSM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b> ${item.gsm} gsm<br/>
          <b>Harga &nbsp;&nbsp;&nbsp;:</b> ${formatCurrency(item.harga_lembar)}
        </div>
        <span style="font-size:12px;color:#9CA3AF">Tindakan ini tidak bisa dibatalkan.</span>
      `,
      showCancelButton: true,
      confirmButtonText: 'Ya, Hapus!',
      cancelButtonText: 'Batal',
      confirmButtonColor: '#EF4444',
      cancelButtonColor: '#6B7280',
    })
    if (!r.isConfirmed) return

    try {
      // Backend reads $substance_id from URL param first,
      // then falls back to $this->delete('id_paperbag') from body.
      // We send both to cover either routing style.
      const body = new URLSearchParams()
      body.append('id_paperbag', item.id)

      const { data } = await axios.delete<ApiResponse>(
        `/Admin/Paperbag/PaperbagSheetPricesDelete/${item.id}`,
        {
          data: body.toString(),
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        }
      )

      if (data?.status === 200) {
        Swal.fire({
          icon: 'success',
          title: 'Berhasil Dihapus!',
          text: `${item.name} ${item.gsm} gsm (${item.keterangan}) berhasil dihapus.`,
          timer: 1800,
          showConfirmButton: false,
        })
        await refetch()
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Gagal Menghapus',
          text: data?.message || 'Data tidak ditemukan atau gagal dihapus.',
          confirmButtonColor: '#EF4444',
        })
      }
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Gagal!', text: getErrMsg(err, 'Gagal menghapus data') })
    }
  }

  const closeModal = () => { if (!isPosting) { setShowViewModal(false); setShowEditModal(false); setSelectedItem(null) } }

  // ===== FORM PREVIEW HELPER =====
  const calcPreview = (form: typeof EMPTY_FORM, size?: SheetSize) => {
    if (!size || !form.harga_lembar) return null
    const area = calcAreaM2(size.panjang_mm, size.lebar_mm)
    return area > 0 ? parseFloat(form.harga_lembar) / area : null
  }

  // ===== RENDER =====
  if (loading) return <LoadingState icon="mdi:tag-multiple-outline" message="Memuat data Harga Sheet Paperbag..." />

  return (
    <div className="space-y-5 p-4 md:p-6 bg-slate-50 min-h-screen">

      {/* ===== HEADER ===== */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-emerald-600 rounded-xl flex items-center justify-center shadow">
            <Icon icon="mdi:tag-multiple-outline" className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-800 leading-tight">Harga Sheet Paperbag</h1>
            <p className="text-slate-400 text-sm mt-0.5">Kelola harga berdasarkan material, ukuran, dan GSM</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleRefresh} variant="outline" size="md" icon="mdi:refresh">Refresh</Button>
          <Button onClick={() => { setAddForm(EMPTY_FORM); setShowAddModal(true) }} variant="primary" size="md" icon="mdi:plus">
            Tambah Harga
          </Button>
        </div>
      </div>

      {/* ===== STATS ===== */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon="mdi:format-list-bulleted" label="Total Variasi"
          value={String(stats.total)} sub={`${stats.uniqueMat} material · ${stats.uniqueSize} ukuran`}
          accent="bg-emerald-100 text-emerald-600" />
        <StatCard icon="mdi:currency-idr" label="Rentang Harga"
          value={`${formatCurrency(stats.minPrice)} – ${formatCurrency(stats.maxPrice)}`}
          sub={`Rata-rata ${formatCurrency(stats.avgPrice)}`}
          accent="bg-blue-100 text-blue-600" />
        <StatCard icon="mdi:weight" label="Rentang GSM"
          value={`${stats.minGsm} – ${stats.maxGsm} gsm`}
          sub={`${stats.total} entri harga tersedia`}
          accent="bg-amber-100 text-amber-600" />
        <StatCard icon="mdi:view-grid-outline" label="Jenis Material"
          value={String(stats.uniqueMat)}
          sub={`${stats.uniqueSize} ukuran sheet aktif`}
          accent="bg-purple-100 text-purple-600" />
      </div>

      {/* ===== FILTERS ===== */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 space-y-3">
        {/* Material filter */}
        <div>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Icon icon="mdi:material-ui" className="w-3.5 h-3.5" />
            Filter Material
          </p>
          <div className="flex flex-wrap gap-2">
            <FilterChip active={filterMat === 'all'} onClick={() => setFilterMat('all')}
              icon="mdi:select-all" label="Semua"
              count={priceList.length} />
            {uniqueMats.map(type => {
              const s = getMStyle(type)
              const cnt = priceList.filter(p => p.material_type === type).length
              return (
                <FilterChip key={type} active={filterMat === type} onClick={() => setFilterMat(type)}
                  icon={s.icon} label={s.label} count={cnt} />
              )
            })}
          </div>
        </div>

        {/* Size filter */}
        <div>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Icon icon="mdi:ruler-square" className="w-3.5 h-3.5" />
            Filter Ukuran Sheet
          </p>
          <div className="flex flex-wrap gap-2">
            <FilterChip active={filterSize === 'all'} onClick={() => setFilterSize('all')}
              icon="mdi:select-all" label="Semua Ukuran"
              count={new Set(priceList.map(p => p.sheet_size_id)).size} />
            {uniqueSizes.map(size => {
              const cnt = priceList.filter(p => p.sheet_size_id === size.id).length
              return (
                <FilterChip key={size.id} active={filterSize === size.id} onClick={() => setFilterSize(size.id)}
                  icon="mdi:ruler" label={size.code} count={cnt} />
              )
            })}
          </div>
        </div>

        {/* Summary bar */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
          <p className="text-sm text-slate-500">
            Menampilkan{' '}
            <span className="font-semibold text-emerald-600">{filtered.length}</span>
            {' '}dari <span className="font-semibold">{stats.total}</span> variasi
            {' '}dalam <span className="font-semibold">{Object.keys(grouped).length}</span> grup
          </p>
          {(filterMat !== 'all' || filterSize !== 'all') && (
            <button
              onClick={() => { setFilterMat('all'); setFilterSize('all') }}
              className="text-xs text-slate-400 hover:text-slate-700 flex items-center gap-1 transition-colors"
            >
              <Icon icon="mdi:close-circle-outline" className="w-3.5 h-3.5" />
              Reset filter
            </button>
          )}
        </div>
      </div>

      {/* ===== PRICE GROUPS ===== */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-20 bg-white rounded-xl border border-slate-100 shadow-sm">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
              <Icon icon="mdi:tag-off-outline" className="w-8 h-8 text-slate-300" />
            </div>
            <p className="text-slate-400 font-medium">Tidak ada data yang cocok dengan filter saat ini</p>
            <Button variant="outline" size="sm" onClick={() => { setFilterMat('all'); setFilterSize('all') }} icon="mdi:filter-off">
              Reset Filter
            </Button>
          </div>
        ) : (
          Object.entries(grouped).map(([key, items]) => {
            const first = items[0]
            const ms = getMStyle(first.material_type)
            const area = formatAreaM2(first.panjang_mm, first.lebar_mm)
            const avgGroupPrice = items.reduce((s, i) => s + parseFloat(i.harga_lembar), 0) / items.length

            return (
              <div key={key} className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">

                {/* Group header */}
                <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    {/* Material icon pill */}
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${ms.lightBg}`}>
                      <Icon icon={ms.icon} className={`w-5 h-5 ${ms.text}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-800 text-base">{first.name}</span>
                        <MatBadge type={first.material_type} />
                        {first.is_premium === '1' && (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-yellow-100 text-yellow-700 rounded text-xs font-semibold">
                            <Icon icon="mdi:star" className="w-3 h-3" /> Premium
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-slate-400 mt-0.5 flex items-center gap-2">
                        <Icon icon="mdi:ruler" className="w-3.5 h-3.5" />
                        {first.code} • {first.keterangan} • {area}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-xs text-slate-400">Rata-rata harga</p>
                      <p className="text-sm font-bold text-slate-700">{formatCurrency(avgGroupPrice.toFixed(0))}</p>
                    </div>
                    <span className="text-xs bg-slate-100 text-slate-500 px-2.5 py-1 rounded-full font-medium">
                      {items.length} variasi GSM
                    </span>
                  </div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="px-5 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider w-28">GSM</th>
                        <th className="px-5 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Harga / Lembar</th>
                        <th className="px-5 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Harga / m²</th>
                        <th className="px-5 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Update</th>
                        <th className="px-5 py-2.5 text-right text-xs font-semibold text-slate-400 uppercase tracking-wider">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {items.map(item => {
                        const areaVal = calcAreaM2(item.panjang_mm, item.lebar_mm)
                        const pricePerM2 = areaVal > 0 ? parseFloat(item.harga_lembar) / areaVal : 0
                        const pk = priceKey(item)

                        return (
                          <tr key={pk} className="hover:bg-slate-50/80 transition-colors group">
                            <td className="px-5 py-3 whitespace-nowrap">
                              <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-lg">
                                <Icon icon="mdi:weight" className="w-3 h-3 text-slate-400" />
                                {item.gsm} gsm
                              </span>
                            </td>
                            <td className="px-5 py-3 whitespace-nowrap">
                              <span className="text-sm font-bold text-slate-800">{formatCurrency(item.harga_lembar)}</span>
                            </td>
                            <td className="px-5 py-3 whitespace-nowrap">
                              <span className="text-sm text-slate-500">{formatCurrency(pricePerM2.toFixed(0))}</span>
                            </td>
                            <td className="px-5 py-3 whitespace-nowrap">
                              {item.updated_at ? (
                                <span className="text-xs text-slate-400">{formatDate(item.updated_at)}</span>
                              ) : (
                                <span className="text-xs text-slate-300 italic">—</span>
                              )}
                            </td>
                            <td className="px-5 py-3 whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  onClick={() => handleViewClick(item)}
                                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                  title="Lihat Detail"
                                >
                                  <Icon icon="mdi:eye-outline" className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleEditClick(item)}
                                  className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                                  title="Edit"
                                >
                                  <Icon icon="mdi:pencil-outline" className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleDelete(item)}
                                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                  title="Hapus"
                                >
                                  <Icon icon="mdi:delete-outline" className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>

                    {/* Group footer with min/max */}
                    {items.length > 1 && (
                      <tfoot>
                        <tr className="bg-slate-50/60 border-t border-slate-100">
                          <td className="px-5 py-2 text-xs text-slate-400 font-medium">
                            {items.length} GSM
                          </td>
                          <td className="px-5 py-2 text-xs text-slate-400">
                            {formatCurrency(Math.min(...items.map(i => parseFloat(i.harga_lembar))))}
                            {' '}<span className="text-slate-300">–</span>{' '}
                            {formatCurrency(Math.max(...items.map(i => parseFloat(i.harga_lembar))))}
                          </td>
                          <td colSpan={3} />
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>
            )
          })
        )}
      </div>

      {/* ===== VIEW MODAL ===== */}
      <Modal isOpen={showViewModal} onClose={closeModal} title="Detail Harga Sheet" size="md"
        footer={
          <>
            <Button variant="outline" onClick={closeModal}>Tutup</Button>
            <Button variant="primary" onClick={() => selectedItem && handleEditClick(selectedItem)} icon="mdi:pencil-outline">
              Edit Harga
            </Button>
          </>
        }
      >
        {selectedItem && (() => {
          const ms = getMStyle(selectedItem.material_type)
          const area = calcAreaM2(selectedItem.panjang_mm, selectedItem.lebar_mm)
          const pricePerM2 = area > 0 ? parseFloat(selectedItem.harga_lembar) / area : 0
          return (
            <div className="space-y-4">
              {/* Identity banner */}
              <div className={`flex items-center gap-4 p-4 rounded-xl ${ms.lightBg} ${ms.border} border`}>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 bg-white/70`}>
                  <Icon icon={ms.icon} className={`w-6 h-6 ${ms.text}`} />
                </div>
                <div>
                  <p className="font-bold text-slate-800">{selectedItem.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <MatBadge type={selectedItem.material_type} />
                    <span className="text-sm text-slate-500">{selectedItem.gsm} gsm</span>
                    {selectedItem.is_premium === '1' && (
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded font-semibold">⭐ Premium</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Price info */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Harga / Lembar', value: formatCurrency(selectedItem.harga_lembar), icon: 'mdi:currency-idr', color: 'text-emerald-700' },
                  { label: 'Harga / m²', value: formatCurrency(pricePerM2.toFixed(0)), icon: 'mdi:select-all', color: 'text-blue-700' },
                ].map(({ label, value, icon, color }) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                    <p className="text-xs text-slate-400 flex items-center gap-1 mb-1">
                      <Icon icon={icon} className="w-3.5 h-3.5" />{label}
                    </p>
                    <p className={`text-base font-bold ${color}`}>{value}</p>
                  </div>
                ))}
              </div>

              {/* Dimension info */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Kode', value: selectedItem.code, icon: 'mdi:barcode' },
                  { label: 'Ukuran', value: `${formatCm(selectedItem.panjang_mm)} × ${formatCm(selectedItem.lebar_mm)}`, icon: 'mdi:ruler' },
                  { label: 'Luas', value: formatAreaM2(selectedItem.panjang_mm, selectedItem.lebar_mm), icon: 'mdi:crop-square' },
                ].map(({ label, value, icon }) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                    <p className="text-xs text-slate-400 flex items-center gap-1 mb-1">
                      <Icon icon={icon} className="w-3.5 h-3.5" />{label}
                    </p>
                    <p className="text-sm font-semibold text-slate-700">{value}</p>
                  </div>
                ))}
              </div>

              {/* Metadata */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2 text-sm">
                {[
                  { label: 'Keterangan', value: selectedItem.keterangan },
                  { label: 'ID Record', value: <span className="font-mono text-slate-600">{selectedItem.id}</span> },
                  { label: 'Terakhir Update', value: formatDate(selectedItem.updated_at) },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between items-center">
                    <span className="text-slate-400">{label}</span>
                    <span className="text-slate-700 font-medium">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          )
        })()}
      </Modal>

      {/* ===== ADD MODAL ===== */}
      <Modal isOpen={showAddModal} onClose={() => !isPosting && setShowAddModal(false)}
        title="Tambah Harga Sheet Baru" size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => !isPosting && setShowAddModal(false)} disabled={isPosting}>Batal</Button>
            <Button variant="primary" onClick={handleAdd} loading={isPosting} disabled={isPosting} icon="mdi:check">
              {isPosting ? 'Menyimpan...' : 'Simpan Data'}
            </Button>
          </>
        }
      >
        <PriceForm
          form={addForm}
          onFormChange={setAddForm}
          materialTypes={materialTypes}
          sheetSizes={sheetSizes}
          selectedSize={selectedAddSize}
          selectedMaterial={selectedAddMaterial}
          disabled={isPosting}
          accentClass="bg-blue-50 border-blue-200"
          previewAccentClass="bg-emerald-50 border-emerald-200"
          previewTextColor="text-emerald-700"
          previewValueColor="text-emerald-900"
          infoIcon="mdi:information-outline"
          infoIconBg="bg-blue-100"
          infoIconColor="text-blue-600"
          infoTitle="Tambah Variasi Harga Baru"
          infoDesc="Isi semua field untuk menambahkan kombinasi material, ukuran, dan GSM."
        />
      </Modal>

      {/* ===== EDIT MODAL ===== */}
      <Modal isOpen={showEditModal} onClose={closeModal} closeOnOverlayClick={!isPosting}
        title={`Edit — ${selectedItem?.name} ${selectedItem?.gsm} gsm`} size="lg"
        footer={
          <>
            <Button variant="outline" onClick={closeModal} disabled={isPosting}>Batal</Button>
            <Button variant="primary" onClick={handleUpdate} loading={isPosting} disabled={isPosting} icon="mdi:check">
              {isPosting ? 'Menyimpan...' : 'Simpan Perubahan'}
            </Button>
          </>
        }
      >
        {selectedItem && (
          <PriceForm
            form={editForm}
            onFormChange={setEditForm}
            materialTypes={materialTypes}
            sheetSizes={sheetSizes}
            selectedSize={selectedEditSize}
            selectedMaterial={selectedEditMaterial}
            disabled={isPosting}
            accentClass="bg-amber-50 border-amber-200"
            previewAccentClass="bg-amber-50 border-amber-200"
            previewTextColor="text-amber-700"
            previewValueColor="text-amber-900"
            infoIcon="mdi:pencil-outline"
            infoIconBg="bg-amber-100"
            infoIconColor="text-amber-600"
            infoTitle={`Mode Edit — ID: ${selectedItem.id}`}
            infoDesc={`Perbarui data harga untuk ${selectedItem.name} ${selectedItem.gsm} gsm`}
          />
        )}
      </Modal>

    </div>
  )
}

// ============ PRICE FORM (shared for add/edit) ============
interface PriceFormProps {
  form: typeof EMPTY_FORM
  onFormChange: (f: typeof EMPTY_FORM) => void
  materialTypes: MaterialType[]
  sheetSizes: SheetSize[]
  selectedSize?: SheetSize
  selectedMaterial?: MaterialType
  disabled: boolean
  accentClass: string
  previewAccentClass: string
  previewTextColor: string
  previewValueColor: string
  infoIcon: string
  infoIconBg: string
  infoIconColor: string
  infoTitle: string
  infoDesc: string
}

function PriceForm({
  form, onFormChange, materialTypes, sheetSizes, selectedSize, selectedMaterial,
  disabled, accentClass, previewAccentClass, previewTextColor, previewValueColor,
  infoIcon, infoIconBg, infoIconColor, infoTitle, infoDesc,
}: PriceFormProps) {
  const previewPricePerM2 = useMemo(() => {
    if (!selectedSize || !form.harga_lembar) return null
    const area = calcAreaM2(selectedSize.panjang_mm, selectedSize.lebar_mm)
    return area > 0 ? parseFloat(form.harga_lembar) / area : null
  }, [selectedSize, form.harga_lembar])

  const isPreviewReady = form.gsm && form.harga_lembar && form.material_type_id && form.sheet_size_id

  return (
    <div className="space-y-4">
      {/* Info banner */}
      <div className={`flex items-center gap-3 p-3.5 rounded-lg border ${accentClass}`}>
        <div className={`w-9 h-9 ${infoIconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
          <Icon icon={infoIcon} className={`w-4.5 h-4.5 ${infoIconColor}`} />
        </div>
        <div>
          <p className={`text-sm font-semibold ${infoIconColor.replace('text-', 'text-').replace('-600', '-800')}`}>{infoTitle}</p>
          <p className={`text-xs mt-0.5 ${infoIconColor.replace('-600', '-600')}`}>{infoDesc}</p>
        </div>
      </div>

      {/* Two-column layout for selects */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Material */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
            <Icon icon="mdi:material-ui" className="w-4 h-4 text-slate-400" />
            Material <span className="text-red-400">*</span>
          </label>
          <select
            value={form.material_type_id}
            onChange={e => onFormChange({ ...form, material_type_id: e.target.value })}
            disabled={disabled}
            className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-300 bg-white disabled:opacity-60"
          >
            <option value="">— Pilih Material —</option>
            {materialTypes.map(m => (
              <option key={m.id} value={m.id}>
                {m.name} ({m.material_type}){m.is_premium === '1' ? ' ⭐' : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Sheet size */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
            <Icon icon="mdi:ruler" className="w-4 h-4 text-slate-400" />
            Ukuran Sheet <span className="text-red-400">*</span>
          </label>
          <select
            value={form.sheet_size_id}
            onChange={e => onFormChange({ ...form, sheet_size_id: e.target.value })}
            disabled={disabled}
            className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-300 bg-white disabled:opacity-60"
          >
            <option value="">— Pilih Ukuran —</option>
            {sheetSizes.map(s => (
              <option key={s.id} value={s.id}>
                {s.keterangan} ({s.code}) — {formatAreaM2(s.panjang_mm, s.lebar_mm)}
              </option>
            ))}
          </select>
          {selectedSize && (
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <Icon icon="mdi:crop-square" className="w-3.5 h-3.5" />
              {formatCm(selectedSize.panjang_mm)} × {formatCm(selectedSize.lebar_mm)} = {formatAreaM2(selectedSize.panjang_mm, selectedSize.lebar_mm)}
            </p>
          )}
        </div>
      </div>

      {/* GSM + Harga */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="GSM *" type="number" min={1} step={1}
          placeholder="Contoh: 250"
          value={form.gsm}
          onChange={e => onFormChange({ ...form, gsm: e.target.value })}
          disabled={disabled}
          leftIcon="mdi:weight"
        />
        <Input
          label="Harga Lembar (Rp) *" type="number" min={1} step={100}
          placeholder="Contoh: 2500"
          value={form.harga_lembar}
          onChange={e => onFormChange({ ...form, harga_lembar: e.target.value })}
          disabled={disabled}
          leftIcon="mdi:currency-idr"
        />
      </div>

      {/* Live preview */}
      {isPreviewReady && (
        <div className={`rounded-xl px-4 py-3.5 border ${previewAccentClass}`}>
          <p className={`text-xs font-semibold ${previewTextColor} flex items-center gap-1.5 mb-3`}>
            <Icon icon="mdi:eye-check-outline" className="w-4 h-4" />
            Preview Data
          </p>
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
            {[
              { label: 'Material', value: selectedMaterial ? `${selectedMaterial.name} (${selectedMaterial.material_type})` : '—' },
              { label: 'Ukuran', value: selectedSize?.keterangan || '—' },
              { label: 'GSM', value: `${form.gsm} gsm` },
              { label: 'Harga Lembar', value: formatCurrency(form.harga_lembar) },
              ...(previewPricePerM2 !== null ? [{ label: 'Harga / m²', value: formatCurrency(previewPricePerM2.toFixed(0)) }] : []),
              ...(selectedSize ? [{ label: 'Luas Sheet', value: formatAreaM2(selectedSize.panjang_mm, selectedSize.lebar_mm) }] : []),
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between gap-2">
                <span className={previewTextColor}>{label}:</span>
                <span className={`font-semibold ${previewValueColor}`}>{value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}